

const Instructors = () => {
    return (
        <div>
            
        </div>
    );
};

export default Instructors;