

const EnrolledClasses = () => {
    return (
        <div>
            
        </div>
    );
};

export default EnrolledClasses;