

const Payment = () => {
    return (
        <div>
            
        </div>
    );
};

export default Payment;