// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyATKzy0qgo7KXJlm7VGm0620g-7ZB_aGow",
  authDomain: "dancing-school-27a07.firebaseapp.com",
  projectId: "dancing-school-27a07",
  storageBucket: "dancing-school-27a07.appspot.com",
  messagingSenderId: "987737232024",
  appId: "1:987737232024:web:89b1b502662e10308476ed"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;