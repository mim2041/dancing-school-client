
# The name of my website is Dancing School. Here is the logo 
The Website is about a dance school that provides many types of dances. The functionalities that I have added in my website is written below:
* The website design is made attractive.
* There are some pages can any user can view without login, and some other pages can only visit the authorized user.
* There are classes page where any visitor can see the classes that our school provides.
* There is a instructors page, where anyone can see our instructors who takes the classes of our institutes.
* There are three types of users, who have different dashboards to view the informations in their own perspective.

# Live link of my website: https://dancing-school-27a07.web.app/